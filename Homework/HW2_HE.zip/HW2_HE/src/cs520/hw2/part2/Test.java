package cs520.hw2.part2;

public class Test {

	public static void main(String[] args) {
		// declare a variable
		Course currentCourse;
		
		// regular course info
		System.out.println("Taking a regular course...");
		
		// create a Course object
		currentCourse = new Course("CS520", 390, 4);
		
		System.out.println("Printing...\n" + currentCourse.toString());
		
		// online course info
		System.out.println("\nTaking an online course...");
		
		// create an Online Course object
		currentCourse = new OnlineCourse("CS520", 760, 4, 60);
		
		System.out.println("Printing...\n" + currentCourse.toString());
	}

}
