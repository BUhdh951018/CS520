package cs520.hw2.part2;

public class OnlineCourse extends Course{
	// instance variables
	private int technologyFee;
	
	// constructor
	public OnlineCourse(String courseName, int numberOfCredits, int costPerCredit, int technologyFee) {
		super(courseName, numberOfCredits, costPerCredit);
		this.technologyFee = technologyFee;
		
		System.out.println("In OnlineCourse Constructor values set: \n CourseName = " + 
		getCourseName() + ", CostPerCredit = $" + getCostPerCredit() + ", NumberOfCredits = " + 
		getNumberOfCredits() + ", TechnologyFee = $" + getTechnologyFee());
	}
    
	// getter setter of the variables
	public int getTechnologyFee() {
		return technologyFee;
	}

	public void setTechnologyFee(int technologyFee) {
		this.technologyFee = technologyFee;
	}
	// override the method that return the tuition
	public int getTotalTuition() {
		return getTechnologyFee() * getNumberOfCredits() + super.getTotalTuition();
	}
	
	// override the toString method
	public String toString() {
		return "OnlineCourse: " + getCourseName() + " @ $" + getTotalTuition();
	}
}
